# -*- coding: utf-8 -*-
r"""
自动登录 my.telegram.org，创建 API 应用，提取 api_id / api_hash 并写入 config.json。

用法:
    .venv\Scripts\python get_api.py
   手动填写PHONE = "  "          # 手机号（国际格式）
流程:
    1. 用 Playwright 打开真实浏览器访问 my.telegram.org
    2. 自动填写手机号（验证码会发到已打开的 Telegram Desktop）
    3. 自动填写创建应用表单并提取 api_id / api_hash
"""
import json
import os
import re
import sys
import time
from pathlib import Path

# 优先使用项目内下载的浏览器（避免改动 AppData）
_BROWSERS = Path(__file__).parent / ".venv" / "browsers"
if _BROWSERS.exists() and not os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(_BROWSERS)

from playwright.sync_api import sync_playwright

BASE = Path(__file__).parent
CONFIG_FILE = BASE / "config.json"
CODE_FILE = BASE / "_pending_code.txt"
PHONE = "  "          # 手机号（国际格式）
APP_TITLE = "MsgGuardian2026"    # 应用标题（必填）
APP_SHORT = "MsgGuardian"        # 短名，5-32位字母数字下划线（必填）
APP_URL = ""                     # 网址（可空）
APP_PLATFORM = "Desktop"         # 平台
APP_DESC = "Auto record group messages to excel locally."  # 描述（必填）


def log(*a):
    print("[get_api]", *a, flush=True)


def load_config():
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_config(cfg):
    CONFIG_FILE.write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    log("已写入", CONFIG_FILE)


def submit_form(page, candidates):
    """点击可见的提交按钮；找不到可见按钮时回车提交。"""
    for sel in candidates:
        btn = page.query_selector(sel)
        if not btn:
            continue
        try:
            if btn.is_visible():
                btn.click()
                return True
        except Exception:
            pass
    try:
        page.keyboard.press("Enter")
    except Exception:
        pass
    return False


def is_logged_in(page):
    """通过 my.telegram.org 的会话 cookie 判断是否已登录（能感知其他标签页的登录）。"""
    try:
        for c in page.context.cookies("https://my.telegram.org"):
            if c["name"] in ("stel_ssid", "stel_token", "stel_web_session", "stel_web_ssid"):
                return True
    except Exception:
        pass
    return False


def has_login_form(page):
    """页面是否还停留在任何登录/验证码/密码表单。"""
    return (
        page.query_selector(
            'input[name="phone"], input#my_login_phone, input[placeholder*="hone" i]') is not None
        or page.query_selector(
            'input[name="code"], input[name="phone_code"], input[placeholder*="code" i]') is not None
        or page.query_selector('input[type="password"]') is not None
    )


def find_phone_login(page):
    """如果停在登录页，自动填手机号并提交（点可见的 Next 按钮）。"""
    phone_input = page.query_selector(
        'input[name="phone"], input#my_login_phone, input[placeholder*="hone" i]')
    if phone_input:
        log("检测到登录页，填写手机号……")
        phone_input.fill(PHONE.lstrip("+"))
        submit_form(page, [
            'button:has-text("Next")', 'button:has-text("下一步")',
            'button[type="submit"]', 'input[type="submit"]',
        ])
        page.wait_for_timeout(3000)
        return True
    return False


def wait_login_completed(page, timeout=600):
    """
    等待用户完成登录。两种方式任选：
      1) 在浏览器窗口里手动输入验证码并登录（推荐）；
      2) 把验证码发给我，我写入 _pending_code.txt，脚本自动填入。
    当页面不再出现任何登录表单（已进入 my.telegram.org）即视为登录完成。
    """
    log("需要登录验证码（会发到已打开的 Telegram Desktop）……可以直接在浏览器窗口里输码登录，或把验证码发给我。")
    deadline = time.time() + timeout
    while time.time() < deadline:
        # 方式2：我写入的验证码文件
        if CODE_FILE.exists():
            val = CODE_FILE.read_text(encoding="utf-8").strip()
            CODE_FILE.unlink(missing_ok=True)
            if val:
                code_input = page.query_selector(
                    'input[name="code"], input[name="phone_code"], input[placeholder*="code" i]')
                if code_input:
                    log("填写验证码……")
                    try:
                        code_input.fill(val)
                    except Exception:
                        pass
                    submit_form(page, [
                        'button[type="submit"]', 'input[type="submit"]',
                        'button:has-text("Login")', 'button:has-text("登录")',
                        'button:has-text("Next")',
                    ])
                    page.wait_for_timeout(3000)
        # 登录完成：不再有登录表单，或已有会话 cookie（可能是你在别的标签页登录的）
        try:
            if not has_login_form(page) or is_logged_in(page):
                log("登录完成。")
                return
        except Exception:
            pass
        time.sleep(1)
    raise TimeoutError("等待登录超时(%s秒)" % timeout)


def handle_login(page):
    page.goto("https://my.telegram.org/apps", wait_until="domcontentloaded")
    page.wait_for_timeout(1500)
    if not has_login_form(page) or is_logged_in(page):
        log("检测到已登录，直接继续……")
        return page  # 已经登录

    try:
        find_phone_login(page)
    except Exception as e:
        log("自动填手机号失败(%s)，请在浏览器里手动输入手机号并登录。" % e)
    wait_login_completed(page)
    page.goto("https://my.telegram.org/apps", wait_until="domcontentloaded")
    page.wait_for_timeout(2000)
    return page


def ensure_app_created(page):
    """如果还没有应用，自动创建（动态识别表单字段）。"""
    if not page.query_selector('input[name="app_title"], form input, form textarea, form select'):
        log("未检测到创建表单（可能已有应用），尝试直接提取……")
        return page

    # 打印页面上所有表单控件，便于匹配实际字段名
    try:
        controls = page.evaluate(
            "() => Array.from(document.querySelectorAll('input,select,textarea')).map(e => e.name || e.id || e.placeholder).filter(Boolean)")
        log("页面表单控件:", controls)
    except Exception:
        pass

    def try_fill(selector, value):
        try:
            page.fill(selector, value)
            return True
        except Exception:
            return False

    log("自动填写创建表单……")
    try_fill('input[name="app_title"]', APP_TITLE)
    try_fill('input[name="app_shortname"], input[name="app_short_name"]', APP_SHORT)
    if APP_URL:
        try_fill('input[name="app_url"]', APP_URL)
    try:
        page.select_option('select[name="app_platform"], select[name="app_platform_id"], select', APP_PLATFORM)
    except Exception:
        pass
    if not try_fill('textarea[name="app_description"], textarea', APP_DESC):
        try_fill('input[name="app_desc"], input[placeholder*="escription" i]', APP_DESC)

    # 用 fetch 直接提交到真实接口 /apps/create 并读取服务器响应（确定真实错误）
    try:
        resp_text = page.evaluate("""async () => {
            const form = document.querySelector('#app_create_form');
            if (!form) return 'NO_FORM_FOUND';
            const data = new FormData(form);
            const resp = await fetch('/apps/create', {
                method: 'POST', body: data, credentials: 'include'
            });
            return await resp.text();
        }""")
        resp_str = str(resp_text).strip()
        if resp_str:
            log("服务器返回（错误信息）:", resp_str[:1000])
        else:
            log("服务器返回为空 —— 创建成功！正在刷新应用页……")
            page.goto("https://my.telegram.org/apps", wait_until="domcontentloaded")
            page.wait_for_timeout(2000)
    except Exception as e:
        log("fetch 提交失败(%s)，尝试点按钮……" % e)
        submit_form(page, [
            'button[type="submit"]', 'input[type="submit"]',
            'button:has-text("Create application")', 'button:has-text("创建应用")',
        ])
        page.wait_for_timeout(6000)
    return page


def extract_api(page):
    html = page.content()
    m_id = re.search(r'[Aa]pp\s*[Aa]pi[_ ]?id[^0-9]{0,40}?(\d{6,12})', html)
    m_hm = re.search(r'[Aa]pp\s*[Aa]pi[_ ]?hash[^a-f0-9]{0,40}?([a-f0-9]{20,64})', html)
    if not (m_id and m_hm):
        return None
    return int(m_id.group(1)), m_hm.group(1)


def main():
    cfg = load_config()
    proxy = cfg.get("proxy")
    launch_kwargs = {}
    if proxy and proxy.get("host"):
        # 使用本地代理（如 v2rayN）访问 my.telegram.org
        launch_kwargs["proxy"] = {"server": f"http://{proxy['host']}:{proxy.get('port', 10808)}"}
    profile_dir = str(BASE / "edge_profile")  # 持久化登录，只需登录一次
    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            profile_dir, channel="msedge", headless=False,
            viewport={"width": 1280, "height": 900}, **launch_kwargs)
        page = context.pages[0] if context.pages else context.new_page()
        page.set_default_timeout(10000)
        try:
            handle_login(page)

            if "ERROR" in (page.inner_text("body") or ""):
                log("页面出现 ERROR，内容如下（可能与账号限制有关）：")
                print(page.inner_text("body")[:3000], flush=True)
                raise SystemExit("创建应用失败，请检查页面提示")

            ensure_app_created(page)

            # 创建应用后再次检查是否出现 ERROR（常见于账号限制）
            body_text = page.inner_text("body") or ""
            if "ERROR" in body_text:
                log("页面出现 ERROR，内容如下（可能与账号限制有关）：")
                print(body_text[:3000], flush=True)
                raise SystemExit("创建应用失败，请检查页面提示")

            api = extract_api(page)
            if not api:
                log("未能从页面提取 api_id/api_hash，页面文本：")
                print(page.inner_text("body")[:800], flush=True)
                raise SystemExit("提取失败，请手动打开 my.telegram.org/apps 查看")

            api_id, api_hash = api
            cfg["api_id"] = api_id
            cfg["api_hash"] = api_hash
            cfg["phone"] = PHONE
            cfg.setdefault("output_file", "telegram消息记录.xlsx")
            cfg.setdefault("include_channels", False)
            cfg.setdefault("include_private", False)
            cfg.setdefault("proxy", {"type": "socks5", "host": "127.0.0.1", "port": 10808})
            save_config(cfg)
            log("成功！api_id =", api_id, " api_hash =", api_hash[:8] + "...")
            log("api_id/api_hash 已保存到 config.json")
        except Exception as e:
            log("出错：", e)
            try:
                page.screenshot(path=str(BASE / "debug.png"), full_page=True)
                log("已保存调试截图到 debug.png")
            except Exception:
                pass
            raise
        finally:
            context.close()


if __name__ == "__main__":
    sys.exit(main())
