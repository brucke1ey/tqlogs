# -*- coding: utf-8 -*-
"""
配置见 config.json
"""
import asyncio
import json
import logging
import os
import queue
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter
from telethon import TelegramClient, events
from telethon.tl.types import MessageEntityMention, MessageEntityMentionName

BASE = Path(__file__).parent
CONFIG_FILE = BASE / "config.json"
CODE_FILE = BASE / "_pending_code.txt"
TZ = timezone(timedelta(hours=8))  # 东八区（Asia/Shanghai）
FLUSH_INTERVAL = 10                # 每 10 秒写一次盘
HEADERS = ["时间", "群名称", "群id", "成员名称", "成员id", "消息类型", "消息内容"]


def load_config():
    if not CONFIG_FILE.exists():
        print("缺少 config.json，请先运行 get_api.py 或手动创建该文件。")
        sys.exit(1)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def wait_for_code(timeout=300):
    """等待验证码：支持在控制台直接输入，也支持把验证码发给我写入 _pending_code.txt。"""
    result = queue.Queue()

    def reader():
        try:
            val = input(">>> 请输入 Telegram 登录验证码（已发到 Telegram Desktop）: ").strip()
            result.put(val)
        except Exception:
            pass

    threading.Thread(target=reader, daemon=True).start()
    print(">>> 如果无法在控制台输入，请把验证码发给我，我会写入文件后自动继续。", flush=True)
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not result.empty():
            return result.get_nowait()
        if CODE_FILE.exists():
            val = CODE_FILE.read_text(encoding="utf-8").strip()
            CODE_FILE.unlink(missing_ok=True)
            if val:
                return val
        time.sleep(1)
    raise TimeoutError("等待验证码超时")


class ExcelWriter:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.rows = []  # 内存缓冲，批量落盘
        self._ensure_file()

    def _ensure_file(self):
        if not self.path.exists():
            wb = Workbook()
            ws = wb.active
            ws.title = "群消息"
            ws.append(HEADERS)
            for cell in ws[1]:
                cell.font = Font(bold=True)
            ws.freeze_panes = "A2"
            for i, w in enumerate([20, 24, 14, 24, 14, 12, 60], start=1):
                ws.column_dimensions[get_column_letter(i)].width = w
            wb.save(self.path)
            print(f"[excel] 已创建 {self.path.name}", flush=True)

    def add(self, row):
        self.rows.append(row)

    def flush(self):
        if not self.rows:
            return
        rows = self.rows
        try:
            wb = load_workbook(self.path)
            ws = wb.active
            for r in rows:
                ws.append(r)
            wb.save(self.path)
            self.rows = []  # 只有写盘成功才清空缓冲
            print(f"[excel] 已写入 {len(rows)} 条，共 {ws.max_row - 1} 条", flush=True)
        except PermissionError:
            print("[excel] Excel 文件被占用，稍后重试（消息已缓存，不会丢失）", flush=True)
        except Exception as e:
            print(f"[excel] 写入失败: {e}（消息已缓存，将重试）", flush=True)


def media_label(media) -> str:
    if media is None:
        return "文字"
    if hasattr(media, "photo") and media.photo:
        return "图片"
    kind = type(media).__name__.lower()
    if "document" in kind or "audio" in kind or "video" in kind:
        m = media.document or media.audio or media.video
        try:
            if m and m.mime_type:
                return "文件/" + m.mime_type
        except Exception:
            pass
        return "文件"
    if hasattr(media, "webpage") and media.webpage:
        return "链接"
    if hasattr(media, "geo") and media.geo:
        return "位置"
    if hasattr(media, "poll") and media.poll:
        return "投票"
    return "媒体"


def _start_tdesktop_if_not_running():
    """扫码/免登录模式下，方便用户同时使用：若桌面端未运行则启动它。tdata 模式不会调用。"""
    try:
        out = subprocess.run(["tasklist"], capture_output=True, text=True, timeout=15).stdout
        if "Telegram.exe" in out:
            return
        exe = Path(r"C:\Program Files\WindowsApps\TelegramMessengerLLP.TelegramDesktop_7.0.9.0_x64__t4vj0pshhgkwm\Telegram.exe")
        if exe.exists():
            subprocess.Popen([str(exe)])
        else:
            os.startfile("shell:AppsFolder\\TelegramMessengerLLP.TelegramDesktop_t4vj0pshhgkwm!TelegramDesktop")
        print("已启动 Telegram Desktop。", flush=True)
    except Exception:
        pass


async def main():
    cfg = load_config()
    api_id = cfg.get("api_id")
    api_hash = cfg.get("api_hash")
    phone = cfg.get("phone")
    if not (api_id and api_hash and phone):
        print("config.json 缺少 api_id/api_hash/phone，请先运行 get_api.py。")
        sys.exit(1)

    out_path = BASE / cfg.get("output_file", "telegram消息记录.xlsx")
    include_channels = bool(cfg.get("include_channels", False))
    include_private = bool(cfg.get("include_private", False))

    logging.basicConfig(level=logging.WARNING)

    # 可选代理（如 v2rayN 的本地端口），国内直连 Telegram 需要
    proxy_cfg = cfg.get("proxy") or {}
    proxy = None
    if proxy_cfg.get("host"):
        try:
            import socks
            kind = socks.SOCKS5 if proxy_cfg.get("type", "socks5") == "socks5" else socks.HTTP
            proxy = (kind, proxy_cfg["host"], proxy_cfg.get("port", 10808))
        except ImportError:
            print("[config] 未安装 PySocks，无法使用代理，尝试直连……")

    client = TelegramClient(str(BASE / "recorder.session"), api_id, api_hash, proxy=proxy)
    start_tdesktop = True  # 扫码/已登录时启动桌面端；tdata 模式改为 False

    await client.connect()
    if not await client.is_user_authorized():
        # 选择登录方式：1) 扫码  2) 用 Telegram Desktop 会话(tdata)
        mode = ""
        while mode not in ("1", "2"):
            print("=" * 60, flush=True)
            print("需要登录，请选择方式：", flush=True)
            print("  1) 手机扫码登录（推荐：可与 Telegram Desktop 同时运行）", flush=True)
            print("  2) 使用 Telegram Desktop 会话 tdata（免扫码；录制期间需关闭桌面端）", flush=True)
            try:
                mode = input("请输入 1 或 2: ").strip()
            except Exception:
                mode = ""
        print("=" * 60, flush=True)

        if mode == "2":
            # ----- tdata 方式：使用转换好的 tdata_recorder.session，缺失则自动转换 -----
            start_tdesktop = False  # tdata 模式下不启动桌面端（录制时需保持其关闭）
            tdata_session = BASE / "tdata_recorder.session"
            if not tdata_session.exists():
                print("[tdata] 未找到 tdata_recorder.session，开始自动转换……", flush=True)
                tdata_path = Path(str(cfg.get("tdata_folder") or "")).expanduser()
                if not tdata_path.exists():
                    print(f"[tdata] config.json 的 tdata_folder 不存在: {tdata_path}", flush=True)
                    print("[tdata] 请修改 config.json 中的 tdata_folder 为正确的 tdata 路径。", flush=True)
                    sys.exit(1)
                # 检测 Telegram Desktop 是否在运行，转换前需要关闭
                try:
                    out = subprocess.run(["tasklist"], capture_output=True, text=True, timeout=15).stdout
                    if "Telegram.exe" in out:
                        print("[tdata] 检测到 Telegram Desktop 正在运行，转换前需要关闭它。", flush=True)
                        ans = input("是否自动关闭 Telegram Desktop？(y/n): ").strip().lower()
                        if ans in ("y", "yes"):
                            subprocess.run(["taskkill", "/IM", "Telegram.exe", "/F"],
                                           capture_output=True, text=True)
                            time.sleep(2)
                        else:
                            print("[tdata] 请手动关闭 Telegram Desktop 后重新运行。", flush=True)
                            sys.exit(1)
                except Exception:
                    pass
                passcode = str(cfg.get("tdata_passcode") or "").strip()
                if not passcode:
                    print("提示：若 Telegram Desktop 设置了本地密码(设置→隐私设置→本地密码)，请输入；没有则直接回车。", flush=True)
                    passcode = input("本地密码(没有则直接回车): ").strip()
                print("[tdata] 正在转换 tdata → tdata_recorder.session ...", flush=True)
                try:
                    # 兼容新版 Telegram Desktop(UWP/Store 版) 的 tdata：
                    # map 文件含 opentele 无法识别的 key type 会抛错，但授权数据不依赖 map，
                    # 跳过 map 解析即可正常转换。
                    import opentele.td.account as _td_acc
                    from PyQt5.QtCore import QByteArray

                    _orig_readMapWith = _td_acc.StorageAccount.readMapWith

                    def _patched_readMapWith(self, localKey, legacyPasscode=None):
                        try:
                            self.mapData.read(
                                localKey,
                                legacyPasscode if legacyPasscode is not None else QByteArray(),
                            )
                        except BaseException:
                            pass
                        self.readMtpData()  # 读取授权数据(authKey / userId)

                    _td_acc.StorageAccount.readMapWith = _patched_readMapWith

                    from opentele.api import UseCurrentSession
                    from opentele.td import TDesktop

                    conv = await TDesktop(str(tdata_path), passcode=passcode).ToTelethon(
                        session=str(tdata_session), flag=UseCurrentSession
                    )
                    try:
                        await conv.disconnect()  # 释放会话文件占用
                    except Exception:
                        pass
                    print("[tdata] 转换完成。", flush=True)
                except (SystemExit, KeyboardInterrupt):
                    raise
                except BaseException as e:  # opentele 的异常继承自 BaseException
                    print(f"[tdata] 转换失败: {e}", flush=True)
                    print("[tdata] 常见原因：tdata 受本地密码保护。", flush=True)
                    print("[tdata] 若你设置了本地密码(设置→隐私设置→本地密码)，请重新运行并输入正确密码；", flush=True)
                    print("[tdata] 若从未设置本地密码，说明此 tdata 无法被当前工具解密，请改用扫码方式登录。", flush=True)
                    sys.exit(1)
            await client.disconnect()
            client = TelegramClient(str(tdata_session), api_id, api_hash, proxy=proxy)
            await client.connect()
            if not await client.is_user_authorized():
                print("[tdata] tdata 会话无效或已失效，请重新运行 tdata_login.py 转换。", flush=True)
                sys.exit(1)
            print("[auth] 已使用 Telegram Desktop 会话(tdata)登录。", flush=True)
        else:
            # ----- 扫码方式（绕过短信验证码和 reCAPTCHA）-----
            logged_in = False
            try:
                qr = await client.qr_login()
                for attempt in range(1, 6):
                    print(">>> 请用手机 Telegram 扫码登录（打开 Telegram → 设置 → 设备 → 扫描二维码）", flush=True)
                    try:
                        import segno
                        qr_png = BASE / f"login_qr_{attempt}.png"
                        segno.make(qr.url, error="m").save(qr_png, scale=6, border=2)
                        os.startfile(str(qr_png))
                        print(f">>> 第{attempt}次二维码已打开: {qr_png.name}（{attempt}分钟后自动换新）", flush=True)
                    except Exception:
                        print(">>> 请手动扫码: ", qr.url, flush=True)
                    try:
                        await asyncio.wait_for(qr.wait(), timeout=90)
                        logged_in = True
                        print("[auth] 扫码登录成功，会话已保存！", flush=True)
                        break
                    except asyncio.TimeoutError:
                        print(f"[auth] 第{attempt}次二维码过期，正在生成新二维码……", flush=True)
                        await qr.recreate()
            except SystemExit:
                raise
            except Exception as e:
                print(f"[auth] 扫码登录不可用({e})，尝试手机号验证码……", flush=True)

            if not logged_in and not await client.is_user_authorized():
                await client.send_code_request(phone)
                code = await asyncio.to_thread(wait_for_code)
                await client.sign_in(phone, code)
                print("[auth] 登录成功，会话已保存，以后无需再验证码。", flush=True)

    # 除 tdata 模式外，方便用户同时使用桌面端
    if start_tdesktop:
        _start_tdesktop_if_not_running()

    me = await client.get_me()

    # ===== 独立功能：被@时自动回复 =====
    auto_reply_enabled = bool(cfg.get("auto_reply_enabled", False))
    auto_reply_text = cfg.get("auto_reply_text", "你好，我是机器人赛希，有什么可以帮到你的吗？")
    auto_reply_cooldown = float(cfg.get("auto_reply_cooldown", 15))
    last_reply = {}  # chat_id -> 上次回复时间

    writer = ExcelWriter(out_path)
    count = 0

    @client.on(events.NewMessage())
    async def handler(event):
        nonlocal count
        chat = event.chat
        # 会话类型过滤：默认只记录群（含小群/超级群）
        if chat is None:
            return
        if getattr(chat, "broadcast", False) and not include_channels:
            return  # 频道
        if event.is_private and not include_private:
            return  # 私聊
        if event.is_group:
            pass  # 群，记录
        elif event.is_channel and include_channels:
            pass
        else:
            return

        sender = event.sender
        sender_name = ""
        if sender is not None:
            sender_name = (sender.first_name or "") + " " + (sender.last_name or "")
            sender_name = sender_name.strip() or (sender.username or "")
        elif getattr(chat, "broadcast", False):
            sender_name = chat.title or ""
        sender_id = event.sender_id or ""

        chat_title = ""
        try:
            if getattr(chat, "title", None):
                chat_title = chat.title
            else:
                chat_title = getattr(await event.get_chat(), "title", "")
        except Exception:
            chat_title = ""

        text = event.raw_text or ""
        mtype = "文字"
        if not text and event.message and event.message.media:
            text = media_label(event.message.media)
            mtype = "媒体"

        row = [
            datetime.fromtimestamp(event.message.date.timestamp(), TZ).strftime("%Y-%m-%d %H:%M:%S"),
            chat_title,
            event.chat_id,
            sender_name,
            sender_id,
            mtype,
            text,
        ]
        writer.add(row)
        count += 1
        print(f"[msg] {row[0]} 群[{chat_title or event.chat_id}] {sender_name or sender_id}: {text[:50]}", flush=True)

    # ===== 独立功能：被@时自动回复 =====
    @client.on(events.NewMessage())
    async def mention_handler(event):
        if not auto_reply_enabled:
            return
        msg = event.message
        if event.out or msg is None or not msg.text:
            return  # 自己发的消息 / 无文本内容

        # 判断是否@了自己：实体@用户名 / 实体@用户id / 纯文本@用户名
        mentioned = False
        for ent in (msg.entities or []):
            if isinstance(ent, MessageEntityMention):
                raw = msg.text[ent.offset:ent.offset + ent.length].lstrip("@")
                if raw and me.username and raw.lower() == me.username.lower():
                    mentioned = True
                    break
            elif isinstance(ent, MessageEntityMentionName):
                if ent.user_id == me.id:
                    mentioned = True
                    break
        if not mentioned and me.username:
            if ("@" + me.username.lower()) in msg.text.lower():
                mentioned = True

        if not mentioned:
            return

        # 防刷：同一会话内冷却
        now = time.time()
        if event.chat_id in last_reply and now - last_reply[event.chat_id] < auto_reply_cooldown:
            return
        last_reply[event.chat_id] = now
        try:
            await event.reply(auto_reply_text)
            print(f"[auto-reply] 已回复 {event.chat_id} 的@: {auto_reply_text}", flush=True)
        except Exception as e:
            print(f"[auto-reply] 回复失败: {e}", flush=True)

    await client.start()
    print("=" * 60, flush=True)
    print("开始实时监听所有群消息……关闭本窗口即停止。", flush=True)
    print(f"消息将保存到: {out_path}", flush=True)
    print(f"自动回复(被@时): {'开启' if auto_reply_enabled else '关闭'}", flush=True)
    print("=" * 60, flush=True)

    try:
        while True:
            await asyncio.sleep(FLUSH_INTERVAL)
            writer.flush()
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        writer.flush()
        print(f"本次共记录 {count} 条消息，已全部落盘。", flush=True)
        await client.disconnect()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n已手动停止。")
