# -*- coding: utf-8 -*-
r"""
把 Telegram Desktop 的 tdata 会话转换为 Telethon 会话（tdata_recorder.session）。
之后 recorder.py 选择"tdata 方式"登录时直接使用该会话，无需扫码。

用法:
    .venv\Scripts\python tdata_login.py

注意:
    1. 转换前请先【完全退出】Telegram Desktop，否则文件被占用，转换可能失败或损坏。
    2. 转换出的会话与 Telegram Desktop 共用同一登录密钥，
       录制期间请保持 Telegram Desktop 关闭，否则可能互踢。
    tdata 路径在 config.json 的 "tdata_folder" 中配置。
"""
import asyncio
import json
import sys
from pathlib import Path

BASE = Path(__file__).parent


def get_tdata_path():
    cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    p = (cfg.get("tdata_folder") or "").strip()
    if p and Path(p).exists():
        return Path(p)
    return None


async def main():
    tdata = get_tdata_path()
    if not tdata:
        print("未在 config.json 中找到有效的 tdata_folder 路径。")
        print("请先配置 tdata_folder，或在 config.json 中填写正确的路径。")
        sys.exit(1)

    cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    passcode = (cfg.get("tdata_passcode") or "").strip()

    print("tdata 路径:", tdata)
    print("警告：请确认 Telegram Desktop 已【完全关闭】后再继续。")
    ans = input("确认已关闭 Telegram Desktop？输入 y 继续: ").strip().lower()
    if ans not in ("y", "yes"):
        print("已取消。")
        sys.exit(2)

    if not passcode:
        print("提示：如果 Telegram Desktop 设置了【本地密码】(设置 → 隐私设置 → 本地密码)，")
        print("请输入该密码；没设置则直接回车。")
        passcode = input("本地密码(没有则直接回车): ").strip()

    print("正在转换 tdata → Telethon 会话 ...")

    # 兼容新版 Telegram Desktop(UWP/Store 版) 的 tdata：
    # 其 map 文件含 opentele 无法识别的 key type(如 23)，会抛 "Unknown key type"。
    # 但授权数据(authKey)存在独立的授权文件中，不依赖 map，跳过 map 解析即可正常转换。
    import opentele.td.account as _td_acc
    from PyQt5.QtCore import QByteArray

    _orig_readMapWith = _td_acc.StorageAccount.readMapWith

    def _patched_readMapWith(self, localKey, legacyPasscode=None):
        try:
            self.mapData.read(
                localKey, legacyPasscode if legacyPasscode is not None else QByteArray()
            )
        except BaseException:  # opentele 的异常继承自 BaseException
            pass
        self.readMtpData()  # 读取授权数据(authKey / userId)

    _td_acc.StorageAccount.readMapWith = _patched_readMapWith

    from opentele.api import UseCurrentSession
    from opentele.td import TDesktop

    conv = await TDesktop(str(tdata), passcode=passcode).ToTelethon(
        session=str(BASE / "tdata_recorder.session"), flag=UseCurrentSession
    )
    try:
        await conv.disconnect()  # 释放会话文件占用，避免后续 SQLite 锁定
    except Exception:
        pass
    print("转换完成，会话已保存到: tdata_recorder.session")

    # 验证会话是否可用
    import socks
    from telethon import TelegramClient
    cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    proxy_cfg = cfg.get("proxy") or {}
    proxy = None
    if proxy_cfg.get("host"):
        proxy = (socks.SOCKS5, proxy_cfg["host"], proxy_cfg.get("port", 10808))
    c = TelegramClient(str(BASE / "tdata_recorder.session"), cfg["api_id"], cfg["api_hash"], proxy=proxy)
    await c.connect()
    if await c.is_user_authorized():
        me = await c.get_me()
        print("验证成功，已登录为:", me.id, "username =", me.username)
    else:
        print("警告：会话转换完成，但授权检查未通过（可能 tdata 已失效）。")
    await c.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
