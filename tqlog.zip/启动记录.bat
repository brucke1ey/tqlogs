@echo off
title Telegram Group Message Recorder
cd /d "%~dp0"

echo ============================================
echo   Telegram Group Message Recorder - Starting
echo ============================================
echo.

REM ===== 1. First run: create venv and install dependencies =====
if not exist ".venv\Scripts\python.exe" (
    echo [Setup] Creating Python environment and installing dependencies...
    python -m venv .venv
    if errorlevel 1 goto :err
    ".venv\Scripts\python" -m pip install --disable-pip-version-check -q -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
    if errorlevel 1 goto :err
    echo [Setup] Dependencies installed.
    echo.
)

REM ===== 2. Run the recorder (it starts/closes Telegram Desktop per login mode) =====
if not exist "config.json" (
    echo config.json not found. Edit it first.
    pause
    exit /b 1
)
".venv\Scripts\python" recorder.py
echo.
echo Recording stopped. Close this window.
pause
exit /b 0

:err
echo.
echo Setup failed. Check network / Python, then run this file again.
pause
exit /b 1
